# Compile benchmark comparison

Baseline: `2e2a099cca416c4a3473d1a0a2610a3f679182d4`. Current: `a988ac66dcce313834c9e9457c5eb69a6e42fb01`.

Baseline repository: `/private/tmp/async-stripe-v2-study-20261103/artifact-study/events/workspace`.

Current repository: `/private/tmp/async-stripe-v2-study-20261103/artifact-study/combined/workspace`.


| Workload | Profile | Executable Δ | Stripped Δ | Text Δ | Debug Δ | Stripe rlibs Δ | Stripe rmeta Δ |
|---|---|---:|---:|---:|---:|---:|---:|
| minimal | dev | +128 B (+0.01%) | 0 B (0%) | 0 B (0%) | 0 B (0%) | +48.87 MB (+794.18%) | +11.71 MB (+918.20%) |
| minimal | release | +48.50 KB (+8.53%) | +17.38 KB (+4.24%) | +1.31 KB (+0.49%) | 0 B (0%) | +19.79 MB (+916.75%) | +14.03 MB (+991.17%) |

## Incremental caches

| Workload | Profile | Consumer Δ | Stripe libraries Δ |
|---|---|---:|---:|
| minimal | dev | +160.05 KB (+22.12%) | +147.01 MB (+622.67%) |
