from pathlib import Path
import csv,collections,json,sys
sys.setrecursionlimit(10000)
ROOT=Path(__file__).resolve().parents[1];OUT=Path(__file__).resolve().parent
A=ROOT/'broad-verification/analysis'
def rows(n):return list(csv.DictReader((A/n).open()))
nodes={r['emission_path'] for r in rows('model-module-sccs.csv')}
col=rows('model-colocations.csv');edges={(r['source_emission_path'],r['target_emission_path']) for r in rows('model-module-dependencies.csv') if r['source_emission_path'] in nodes and r['target_emission_path'] in nodes}
parent={n:n for n in nodes}
def find(n):
 if parent[n]!=n:parent[n]=find(parent[n])
 return parent[n]
def union(a,b):
 a,b=find(a),find(b)
 if a!=b:parent[b]=a
for r in col:
 a,b=r['owner_emission_path'],r['payload_emission_path']
 assert a in nodes and b in nodes
 union(a,b)
groups=collections.defaultdict(set)
for n in nodes:groups[find(n)].add(n)
graph={g:set() for g in groups}
for a,b in edges:
 if find(a)!=find(b):graph[find(a)].add(find(b))
index=0;indices={};low={};stack=[];on=set();sccs=[]
def visit(n):
 global index
 indices[n]=low[n]=index;index+=1;stack.append(n);on.add(n)
 for d in graph[n]:
  if d not in indices:visit(d);low[n]=min(low[n],low[d])
  elif d in on:low[n]=min(low[n],indices[d])
 if low[n]==indices[n]:
  comp=[]
  while True:
   d=stack.pop();on.remove(d);comp.append(d)
   if d==n:break
  sccs.append(comp)
for n in sorted(graph):
 if n not in indices:visit(n)
atomic=[]
for component in sccs:
 sites=set().union(*(groups[g] for g in component));owners=sorted({r['owner'] for r in col if r['owner_emission_path'] in sites})
 atomic.append({'model_modules':len(sites),'merged_colocation_groups':len(component),'existing_crates':dict(collections.Counter(Path(s).parts[1] for s in sites)),'owners':owners,'sites':sorted(sites)})
atomic.sort(key=lambda g:(-g['model_modules'],g['sites']))
report={'active_model_modules':len(nodes),'represented_model_edges':len(edges),'colocation_constraints':len(col),'initial_colocation_groups':len(groups),'cycles_between_colocation_groups':sum(len(c)>1 for c in sccs),'minimum_atomic_groups_after_cycle_merges':len(atomic),'largest_groups':atomic[:15],'note':'Colocation components plus SCC merging give lower-bound indivisible model groups under current inherent accessors. This is not a finished package partition; IDs/runtime/facade references and package overhead need separate planning.'}
(OUT/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
for k in ['active_model_modules','initial_colocation_groups','cycles_between_colocation_groups','minimum_atomic_groups_after_cycle_merges']:print(k,report[k])
for r in atomic[:8]:print(r['model_modules'],r['merged_colocation_groups'],r['existing_crates'],r['owners'])
