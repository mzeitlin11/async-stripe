use std::path::Path;
use stripe_openapi_codegen::{codegen::{CodeGen, CodeGenOptions}, crates::{CrateConfig, CrateInfo}, spec::Spec, url_finder::UrlFinder};

fn build(config: CrateConfig) -> anyhow::Result<CodeGen> {
    let input = std::fs::read("spec3.sdk.json")?;
    CodeGen::with_config(Spec::new(serde_json::from_slice(&input)?), UrlFinder::new()?, "1.0.0-rc.9".into(), CodeGenOptions::default(), config)
}
fn main() -> anyhow::Result<()> {
    let root = Path::new("/private/tmp/async-stripe-neutral-refactor-20261107");
    let first = build(CrateConfig::load(Path::new("gen_crates.toml"))?)?;
    first.render_workspace()?.materialize(&root.join("configuration-probe-before"))?;
    let mut info: CrateInfo = toml::from_str(&std::fs::read_to_string("gen_crates.toml")?)?;
    info.crates.iter_mut().find(|c| c.name == "core").unwrap().name = "core_probe".into();
    let second = build(CrateConfig::new(info)?)?;
    assert!(first.crate_config().find("core").is_some());
    assert!(first.crate_config().find("core_probe").is_none());
    assert!(second.crate_config().find("core_probe").is_some());
    assert!(second.crate_config().find("core").is_none());
    second.render_workspace()?.materialize(&root.join("configuration-probe-second"))?;
    first.render_workspace()?.materialize(&root.join("configuration-probe-after"))?;
    Ok(())
}
