This is a read-only placement simulation using the full record-prototype analysis.
No repository files were changed or compiled. `simulate.py` consumes the CSV
artifacts and writes `result.json`; input hashes are recorded in that JSON.

The 237 enabling features map unambiguously to existing request-domain names.
There are 1,459 active model modules and one disabled/unconsumed model (`rule.rs`).
That disabled module is conservatively retained in Shared in every variant.
Reference foundations and shared overrides also stay Shared. Request and
handwritten webhook modules keep their existing physical crates.

Results:

1. Exact requested policy: combine model consumer domains and union the raw
   PaymentMethodDetails owner with its 61 payload sites. Move singleton-domain
   groups there, leave others Shared. This moves 629 active model modules but
   creates a Shared/Payment/client-core cycle: colocated payloads become Shared
   while 22 of their transitive children remain Payment-only.

2. Diagnostic post-colocation propagation: propagate each combined group's
   consumer domains along represented dependencies to a fixed point. This moves
   607 active model modules. Active Shared models fall from 1,041 to 434
   (435 including the disabled Rule). The complete represented graph, request
   dependencies, mandatory Shared edges, and client-core->Shared are acyclic.
   Preserving all existing component-facade reexport edges still produces an
   eight-crate SCC, so this variant requires adapting those exports.

3. Diagnostic preservation of existing component facades: treat each original
   public component facade as an additional consumer before propagation. This
   moves 547 active model modules, leaving 494 active Shared models (495 including
   Rule). Both the represented graph and the graph including those existing
   facade reexports are acyclic. This preserves the current generator's domain
   facade export relationships; it does not preserve old physical paths such as
   stripe_shared::Charge after that declaration moves. Normal generation is a
   separate compatibility question and was not changed by this experiment.

The single 62-site colocation group has consumers in Billing, Core, Payment, and
Terminal, so its raw owner and all payload declarations remain Shared. This
follows the existing inherent-method API requirement, not dependency SCCs.

These simulations reuse existing domain names and make no new crate clusters.
They do not validate rewritten paths, every wildcard export, generated manifest
feature forwarding, or Rust compilation after placement. Those need a real
placement implementation and verifier run before claiming a working layout.
