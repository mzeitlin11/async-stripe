#!/usr/bin/env python3
"""Read represented analysis artifacts and simulate existing-domain placement.

The exact requested policy and a diagnostic variant propagating consumer sets
after colocation are reported separately. No repository files are written.
"""
import argparse
import collections
import csv
import hashlib
import io
import json
from pathlib import Path

SHARED = "async-stripe-shared"
CLIENT = "async-stripe-client-core"
TYPES = "async-stripe-types"
WEBHOOK = "async-stripe-webhook"
FACADE = "async-stripe"


def sccs(nodes, edges):
    successors = {node: set() for node in nodes}
    for source, target in edges:
        successors[source].add(target)
    reach = {}
    for root in sorted(nodes):
        seen, pending = set(), [root]
        while pending:
            node = pending.pop()
            if node in seen:
                continue
            seen.add(node)
            pending.extend(successors[node])
        reach[root] = seen
    groups, done = [], set()
    for root in sorted(nodes):
        if root not in done:
            group = sorted(node for node in nodes if node in reach[root] and root in reach[node])
            groups.append(group)
            done.update(group)
    return groups


def physical_crate(path):
    parts = Path(path).parts
    return parts[1] if parts[0] == "crates" else parts[0]


def run(analysis):
    names = ["components.csv", "items.csv", "model-availability.csv",
             "model-module-dependencies.csv", "model-colocations.csv", "model-group-closures.csv"]
    snapshots = {name: (analysis / name).read_bytes() for name in names}
    rows = {name: list(csv.DictReader(io.StringIO(data.decode()))) for name, data in snapshots.items()}
    components = {row["component"]: row for row in rows["components.csv"]}
    items = rows["items.csv"]
    by_site = collections.defaultdict(list)
    component_roots = {}
    for item in items:
        by_site[item["emission_path"]].append(item)
        if item["origin"].startswith("component:"):
            name = item["origin"][10:]
            if name in components and item["ident"] == components[name]["ident"]:
                component_roots[name] = item
    missing_roots = sorted(set(components) - set(component_roots))
    modules = collections.defaultdict(list)
    for name, item in component_roots.items():
        path = Path(item["emission_path"])
        mod = path.parent.name if path.name == "types.rs" else path.stem
        modules[mod].append(name)
    features = [row["group"] for row in rows["model-group-closures.csv"] if row["scope"] == "feature"]
    unmatched_features = {feature: modules.get(feature, []) for feature in features if len(modules.get(feature, [])) != 1}
    feature_domains = {feature: components[modules[feature][0]]["request_crate"] for feature in features if feature not in unmatched_features}
    availability = {row["emission_path"]: row["availability"] for row in rows["model-availability.csv"]}
    edges = set()
    for row in rows["model-module-dependencies.csv"]:
        source, target = row["source_emission_path"], row["target_emission_path"]
        availability.setdefault(source, row["source_availability"])
        availability.setdefault(target, row["target_availability"])
        edges.add((source, target))
    sites = set(availability)
    kinds, forced = {}, {}
    for site in sorted(sites):
        declarations = by_site[site]
        if site.endswith("/requests.rs"):
            kinds[site] = "requests"
        elif site.startswith(WEBHOOK + "/"):
            kinds[site] = "webhooks"
        elif declarations and all(item["kind"] in {"IdNewtype", "OpaqueObject"} for item in declarations):
            kinds[site] = "references"
        else:
            kinds[site] = "model"
        reasons = []
        if availability[site] == "always" and kinds[site] != "webhooks":
            reasons.append("always")
        if kinds[site] == "references":
            reasons.append("reference foundation")
        if any(item["origin"].startswith("shared:") for item in declarations):
            reasons.append("shared override")
        forced[site] = reasons
    users = {site: set() if condition in {"always", "disabled"} else
             {feature_domains[feature] for feature in condition.split("|") if feature in feature_domains}
             for site, condition in availability.items()}
    models = {site for site in sites if kinds[site] == "model"}
    parent = {site: site for site in sites}

    def find(site):
        while parent[site] != site:
            parent[site] = parent[parent[site]]
            site = parent[site]
        return site

    def union(left, right):
        left, right = find(left), find(right)
        if left != right:
            parent[max(left, right)] = min(left, right)

    unsupported_colocations = []
    for row in rows["model-colocations.csv"]:
        owner, payload = row["owner_emission_path"], row["payload_emission_path"]
        if owner not in models or payload not in models:
            unsupported_colocations.append(row)
        else:
            union(owner, payload)
    groups = collections.defaultdict(set)
    for site in sites:
        groups[find(site)].add(site)
    group_users = {root: set().union(*(users[site] for site in members)) for root, members in groups.items()}
    group_forced = {root: sorted({reason for site in members for reason in forced[site]}) for root, members in groups.items()}
    for root, members in groups.items():
        if all(availability[site] == "disabled" for site in members):
            group_forced[root].append("disabled/unconsumed")
    domains = {row["request_crate"] for row in components.values()} | {SHARED}
    request_domains = {physical_crate(site) for site in sites if kinds[site] == "requests"}

    def evaluate(propagate, preserve_facades=False):
        effective = {root: set(values) for root, values in group_users.items()}
        if preserve_facades:
            for item in items:
                prefix = next((prefix for prefix in ["component:", "object-id:"] if item["origin"].startswith(prefix)), None)
                if prefix is None or not item["public_crate"]:
                    continue
                name = item["origin"][len(prefix):]
                if name not in components:
                    continue
                if prefix == "component:" and item["ident"] != components[name]["ident"]:
                    continue
                effective[find(item["emission_path"])].add(components[name]["request_crate"])
        rounds = 0
        if propagate:
            while True:
                changed = False
                for source, target in sorted(edges):
                    if availability[source] == "disabled":
                        continue
                    source_group, target_group = find(source), find(target)
                    required = effective[source_group]
                    if group_forced[source_group]:
                        required = required | {SHARED}
                    if not required <= effective[target_group]:
                        effective[target_group].update(required)
                        changed = True
                rounds += 1
                if not changed:
                    break
        assignments, explanations = {}, {}
        for site in sorted(sites):
            root = find(site)
            if kinds[site] in {"requests", "webhooks"}:
                assignments[site] = physical_crate(site)
                explanations[site] = "fixed " + kinds[site]
            elif group_forced[root]:
                assignments[site] = SHARED
                explanations[site] = "+".join(group_forced[root])
            elif len(effective[root]) == 1:
                assignments[site] = next(iter(effective[root]))
                explanations[site] = "one consuming domain"
            else:
                assignments[site] = SHARED
                explanations[site] = "multiple consuming domains" if effective[root] else "disabled/unconsumed"
        graph = collections.defaultdict(list)

        def add(source, target, reason, evidence=None):
            if source != target:
                graph[(source, target)].append({"reason": reason, "evidence": evidence})

        for source, target in sorted(edges):
            add(assignments[source], assignments[target], "represented declaration/request/accessor", [source, target])
        for domain in sorted(domains):
            add(domain, SHARED, "existing mandatory shared dependency")
            add(domain, TYPES, "runtime type dependency")
        for domain in sorted(request_domains):
            add(domain, CLIENT, "request APIs depend on client core")
        add(CLIENT, SHARED, "handwritten client-core manifest")
        add(CLIENT, TYPES, "handwritten client-core manifest")
        add(WEBHOOK, SHARED, "handwritten webhook manifest")
        add(WEBHOOK, TYPES, "handwritten webhook manifest")
        for domain in sorted(domains):
            add(WEBHOOK, domain, "webhook optional resource features (upper consumer)")
            add(FACADE, domain, "additive top-level facade (upper consumer)")
        add(FACADE, CLIENT, "top-level facade client APIs")
        add(FACADE, TYPES, "top-level facade runtime types")
        all_nodes = domains | {CLIENT, TYPES, WEBHOOK, FACADE}

        def graph_report(edges_map):
            cycles = [group for group in sccs(all_nodes, edges_map) if len(group) > 1]
            return {"cycles": cycles, "edge_count": len(edges_map),
                    "edges": [{"source": source, "target": target, "reasons": list(reasons)}
                              for (source, target), reasons in sorted(edges_map.items())]}

        no_legacy = graph_report(graph)
        # This mirrors crate_dependencies.rs's public facade uses for top-level
        # component roots and object IDs, including model-only helper schemas.
        for item in items:
            prefix = next((prefix for prefix in ["component:", "object-id:"] if item["origin"].startswith(prefix)), None)
            if prefix is None or not item["public_crate"]:
                continue
            name = item["origin"][len(prefix):]
            if name not in components:
                continue
            if prefix == "component:" and item["ident"] != components[name]["ident"]:
                continue
            add(components[name]["request_crate"], assignments[item["emission_path"]],
                "existing component facade reexport", [name, item["ident"], item["emission_path"]])
        moved = [site for site in sorted(models) if physical_crate(site) != assignments[site]]
        matrix = collections.Counter((physical_crate(site), assignments[site]) for site in moved)
        return {"propagation_rounds": rounds, "model_modules": len(models), "moved_model_modules": len(moved),
                "models_by_proposed_crate": dict(sorted(collections.Counter(assignments[site] for site in models).items())),
                "shared_models_by_reason": dict(sorted(collections.Counter(explanations[site] for site in models if assignments[site] == SHARED).items())),
                "movement_matrix": [{"from": source, "to": target, "modules": count} for (source, target), count in sorted(matrix.items())],
                "aggregate_graph_without_legacy_component_reexports": no_legacy,
                "aggregate_graph_with_existing_component_reexports": graph_report(graph),
                "colocation_groups": [{"modules": sorted(members), "domains": sorted(effective[root]), "proposed_crate": assignments[root]}
                                       for root, members in sorted(groups.items()) if len(members) > 1],
                "assignments": [{"emission_path": site, "kind": kinds[site], "availability": availability[site],
                                 "old_crate": physical_crate(site), "proposed_crate": assignments[site],
                                 "original_domains": sorted(users[site]), "effective_group_domains": sorted(effective[find(site)]),
                                 "reason": explanations[site], "canonical_items": len(by_site[site])} for site in sorted(sites)]}

    exact = evaluate(False)
    repaired = evaluate(True)
    preserve_facades = evaluate(True, True)
    return {"analysis_directory": str(analysis), "input_sha256": {name: hashlib.sha256(data).hexdigest() for name, data in snapshots.items()},
            "assumptions": ["No new crates; current request_crate labels define feature consumer domains.",
                            "Only model emission sites move. Request/webhook modules retain their physical crates.",
                            "Always/reference/override sites remain Shared; colocation groups combine consumer sets.",
                            "Full graph includes all represented edges, request->client-core, client-core->Shared, runtime leaves and existing mandatory Shared dependencies.",
                            "Legacy component reexports are reported separately because they add API dependencies beyond actual represented consumers.",
                            "This does not validate rewritten file paths, manifest feature forwarding, or every public glob export."],
            "features": len(features), "feature_domains": dict(sorted(feature_domains.items())),
            "missing_component_roots": missing_roots, "unmatched_features": unmatched_features,
            "disabled_sites": sorted(site for site in sites if availability[site] == "disabled"),
            "unconsumed_model_sites": sorted(site for site in models if not users[site] and availability[site] != "always"),
            "unsupported_colocations": unsupported_colocations,
            "exact_requested_policy": exact,
            "diagnostic_propagation_after_colocation": repaired,
            "diagnostic_existing_facades_as_consumers": preserve_facades}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("analysis", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    report = run(args.analysis)
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"features": report["features"], "unmatched_features": report["unmatched_features"],
                      "disabled_sites": len(report["disabled_sites"]),
                      **{name: {key: report[name][key] for key in ["moved_model_modules", "models_by_proposed_crate", "shared_models_by_reason"]} |
                         {"cycles_without_legacy_facades": report[name]["aggregate_graph_without_legacy_component_reexports"]["cycles"],
                          "cycles_with_legacy_facades": report[name]["aggregate_graph_with_existing_component_reexports"]["cycles"]}
                         for name in ["exact_requested_policy", "diagnostic_propagation_after_colocation", "diagnostic_existing_facades_as_consumers"]}}, indent=2))


if __name__ == "__main__":
    main()
