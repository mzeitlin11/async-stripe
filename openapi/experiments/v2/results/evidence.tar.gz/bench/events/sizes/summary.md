# Compile benchmark

Complete. Commit: `2e2a099cca416c4a3473d1a0a2610a3f679182d4`. Target: `aarch64-apple-darwin`.

Repository: `/private/tmp/async-stripe-v2-study-20261103/artifact-study/events/workspace`.

Collector: `0.0.0`; source SHA-256: `10ee043482585af87e2ca32a3345ebbd4bc8091b85e87ebda164445b45fd0c53`.

`rustc 1.89.0 (29483883e 2025-08-04)`. Platform: `macos/aarch64`. [Raw data](results.json).

| Workload | Profile | Executable | Stripped | Text sections | Debug sections | Stripe rlibs | Stripe rmeta |
|---|---|---:|---:|---:|---:|---:|---:|
| minimal | dev | 1.04 MB | 683.18 KB | 381.97 KB | 0 B | 6.15 MB | 1.28 MB |
| minimal | release | 568.61 KB | 409.90 KB | 264.43 KB | 0 B | 2.16 MB | 1.42 MB |

## Incremental caches

| Workload | Profile | Consumer | Stripe libraries |
|---|---|---:|---:|
| minimal | dev | 723.59 KB | 23.61 MB |

## Library artifacts

<details>
<summary>minimal/dev</summary>

| Library | rlib | rmeta | Features |
|---|---:|---:|---|
| async-stripe-client-core | 975.58 KB | 273.03 KB | uuid, v2 |
| async-stripe-types | 811.46 KB | 295.06 KB |  |
| async-stripe-v2 | 4.37 MB | 706.96 KB |  |

</details>

<details>
<summary>minimal/release</summary>

| Library | rlib | rmeta | Features |
|---|---:|---:|---|
| async-stripe-client-core | 412.05 KB | 312.56 KB | uuid, v2 |
| async-stripe-types | 413.23 KB | 324.76 KB |  |
| async-stripe-v2 | 1.33 MB | 778.34 KB |  |

</details>

## Retained artifacts

Paths are relative to this report directory. Full targets can include incomplete failed builds.

| Workload/profile | Build | Artifact | Path |
|---|---:|---|---|
| minimal/dev | 1 | executable | [artifacts/minimal-dev/executable](<artifacts/minimal-dev/executable>) |
| minimal/release | 1 | executable | [artifacts/minimal-release/executable](<artifacts/minimal-release/executable>) |

Build commands and explicit environment overrides are saved as `logs/<workload>-<profile>/build-<N>.command.json`. Inherited build inputs are recorded in `results.json`.
