from pathlib import Path
import json,os,re,statistics,subprocess,time
root=Path(__file__).resolve().parent
env=dict(os.environ,CARGO_TARGET_DIR=str(root/'bindings-target'),CARGO_PROFILE_DEV_DEBUG='0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2')
workspaces={'baseline':root/'baseline-workspace','opaque':root/'consumer-workspace'}
packages=['async-stripe-types','async-stripe-shared','async-stripe-client-core','async-stripe-core','async-stripe','slice-compile-probe']
results=[]
for iteration,order in enumerate([['baseline','opaque'],['opaque','baseline']],1):
 for name in order:
  workspace=workspaces[name];manifest=workspace/'compile-probe/Cargo.toml'
  clean=['cargo','+1.89.0','clean','--manifest-path',str(manifest)]
  for package in packages: clean += ['-p',package]
  subprocess.run(clean,cwd=workspace,env=env,check=True,capture_output=True)
  for kind in ['project-clean','warm']:
   command=['cargo','+1.89.0','check','--manifest-path',str(manifest),'--offline']
   start=time.perf_counter();r=subprocess.run(command,cwd=workspace,env=env,capture_output=True,text=True);elapsed=time.perf_counter()-start
   (root/f'compile-{name}-{iteration}-{kind}.log').write_text(r.stdout+r.stderr)
   assert r.returncode==0,(name,kind,r.stderr[-4000:])
   results.append({'scenario':name,'iteration':iteration,'kind':kind,'seconds':elapsed})
   print(results[-1],flush=True)
  dep=max((root/'bindings-target/debug/deps').glob('stripe_shared-*.d'),key=lambda p:p.stat().st_mtime)
  sources=sorted(set(re.findall(r'[^\s:]+\.rs',dep.read_text())))
  assert all(str(workspace) in p for p in sources)
  (root/f'{name}-check-compiled-sources.json').write_text(json.dumps(sources,indent=2)+'\n')
summary={'toolchain':'1.89.0','command':'cargo check','method':'Registry/build dependencies retained; six project packages cleaned before each project-clean check; two alternating runs. Debug info disabled, incremental disabled, two jobs. Exploratory local measurements, not a controlled benchmark.','runs':results,'medians':{name:{kind:statistics.median(r['seconds'] for r in results if r['scenario']==name and r['kind']==kind) for kind in ['project-clean','warm']} for name in workspaces}}
(root/'compile-comparison.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary['medians'],indent=2),flush=True)
