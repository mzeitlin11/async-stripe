use std::path::Path;
use stripe_openapi_codegen::{crates::CrateConfig, output::install_to_repository};
fn main() -> anyhow::Result<()> {
    let args = std::env::args().collect::<Vec<_>>();
    let config = CrateConfig::load(Path::new("gen_crates.toml"))?;
    install_to_repository(Path::new(&args[1]), Path::new(&args[2]), &config)
}
