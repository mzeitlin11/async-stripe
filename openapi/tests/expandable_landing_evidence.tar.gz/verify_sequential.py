from pathlib import Path
import json, os, subprocess, shutil

root = Path("/private/tmp/async-stripe-codegen-landing-20261108/worktree")
work = Path("/private/tmp/async-stripe-codegen-expandables-20261108")
target = Path("/private/tmp/async-stripe-neutral-refactor-20261107/sdk-target")
generator = Path("/private/tmp/async-stripe-codegen-landing-20261108/generator-target")
env = dict(os.environ, CARGO_TARGET_DIR=str(target), CARGO_PROFILE_DEV_DEBUG="0",
           CARGO_INCREMENTAL="0", CARGO_BUILD_JOBS="2", PYTHONDONTWRITEBYTECODE="1")
cases = [("concrete-verification", "verify_generated_workspace.py", []),
         ("full-v1", "verify_opaque_groups.py", ["--full-v1"]),
         ("consumer-layout", "verify_opaque_groups.py", ["--full-v1", "--consumer-layout"])]
cases = cases[1:]
old = work / "before-cache-isolation"
old.mkdir(exist_ok=True)
(old / "README.txt").write_text("Superseded diagnostic runs. Compiler source results were invalidated by reuse of local SDK artifacts across different workspace paths. The sequential runs clean every local SDK package between modes and reject mismatched rustc dep-info.\n")
for name, _, _ in cases:
    previous = work / name
    archived = old / name
    archived.mkdir(exist_ok=True)
    for path in previous.iterdir():
        if path.is_file() and path.suffix in [".json", ".log"] and not (archived / path.name).exists():
            shutil.copyfile(path, archived / path.name)

for name, script, flags in cases:
    workspace = work / name / "workspace"
    print(f"Cleaning local SDK packages before {name}", flush=True)
    metadata = json.loads(subprocess.check_output(
        ["cargo", "+1.89.0", "metadata", "--offline", "--no-deps", "--format-version", "1"],
        cwd=workspace, env=env, text=True))
    command = ["cargo", "+1.89.0", "clean", "--offline"]
    for package in metadata["packages"]:
        command += ["-p", package["name"]]
    with (work / f"clean-before-{name}.log").open("w") as log:
        subprocess.run(command, cwd=workspace, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
        for fixture, package in [("opaque-consumer", "opaque-consumer"), ("opaque-webhook-consumer", "opaque-webhook-consumer")]:
            manifest = work / "full-v1/workspace/openapi/tests/fixtures" / fixture / "Cargo.toml"
            subprocess.run(["cargo", "+1.89.0", "clean", "--offline", "--manifest-path", str(manifest), "-p", package],
                           cwd=workspace, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
    command = ["python3", "-B", str(root / "openapi/tests" / script), *flags,
               "--keep-workspace", "--work-dir", str(work / name),
               "--generator-target-dir", str(generator), "--target-dir", str(target)]
    print(f"Verifying {name} sequentially", flush=True)
    with (work / f"sequential-{name}.log").open("w") as log:
        subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
    if name == "full-v1":
        with (work / "sequential-opaque-facade-clippy.log").open("w") as log:
            subprocess.run(["cargo", "+1.89.0", "clippy", "--offline", "-p", "async-stripe", "--no-default-features",
                            "--features", "full,serialize,deserialize", "--", "-D", "warnings"],
                           cwd=work / name / "workspace", env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
    print(f"Passed {name}", flush=True)
(work / "sequential-verification.json").write_text(json.dumps({
    "modes": [name for name, _, _ in cases],
    "all_passed": True,
    "local_sdk_packages_cleaned_between_modes": True,
    "mismatched_compiler_sources_rejected": True,
}, indent=2) + "\n")
