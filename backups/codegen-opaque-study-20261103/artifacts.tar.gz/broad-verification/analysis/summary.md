# Code Generation Analysis

## Pipeline

- Parsed components: 1470
- Retained components: 1464
- Declared operations: 578
- Generated requests: 547
- Webhook event payloads: 265
- Objects: 6722
- Canonical Rust objects: 6722
- Canonical Rust items: 6859
- Canonical property analysis rounds: 6
- Canonical items with lifetimes: 0
- Canonical items deriving Copy: 538
- Canonical items deriving Eq: 6183
- Fields: 16425
- Enum variants: 20654
- Parsed dependency facts: 3551
- Retained dependency facts: 3543
- Expandable edges used for layout: true
- ID-only edges used for layout: false
- Lowered Rust crate dependencies contain cycles: false
- Crate inference warnings: 0

## Dependency facts

### By representation

- Direct: 918
- Expandable: 326
- IdOnly: 477
- InContainer: 1748
- UnionMember: 74

### By usage

- ModelField: 2385
- RequestParam: 318
- RequestReturn: 562
- WebhookPayload: 278

## Crates

| Crate | Model components | Request components | Requests | Objects | Fields |
|---|---:|---:|---:|---:|---:|
| async-stripe-billing | 136 | 26 | 127 | 1001 | 2675 |
| async-stripe-checkout | 43 | 1 | 6 | 364 | 701 |
| async-stripe-connect | 94 | 14 | 51 | 469 | 1601 |
| async-stripe-core | 206 | 22 | 82 | 1528 | 3676 |
| async-stripe-fraud | 34 | 5 | 15 | 82 | 213 |
| async-stripe-issuing | 24 | 8 | 48 | 271 | 712 |
| async-stripe-misc | 124 | 23 | 71 | 712 | 1334 |
| async-stripe-payment | 62 | 9 | 39 | 728 | 1421 |
| async-stripe-product | 15 | 8 | 34 | 94 | 369 |
| async-stripe-reserve | 8 | 0 | 0 | 17 | 50 |
| async-stripe-shared | 649 | 0 | 0 | 1112 | 2818 |
| async-stripe-terminal | 48 | 5 | 28 | 156 | 464 |
| async-stripe-treasury | 21 | 10 | 46 | 181 | 391 |
| async-stripe-webhook | 0 | 0 | 0 | 7 | 0 |

## Represented model modules

- Active model modules: 1460
- Cross-module model dependencies: 1606
- Strongly connected components: 1460
- Components containing cross-module cycles: 0
- Largest component: 1 modules

These use the same module dependencies as feature availability, after representation and placement. Request modules, reference-only modules, disabled modules, and intra-module references are excluded from the model graph. Singleton components are retained.

`model-module-dependencies.csv` includes the complete availability graph. `model-group-closures.csv` reports always-on modules separately from conditional feature closures; shared conditional modules occur in every requiring group and must not be summed. Counts cover declaration/request emission modules, not handwritten files or module index files.

- Inherent record accessor colocation constraints: 694

`model-colocations.csv` records owner/payload pairs that must share a public crate for inherent decoder methods. These constraints are independent of dependency cycles and do not require sharing a source module.
