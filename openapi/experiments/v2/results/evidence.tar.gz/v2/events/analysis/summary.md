# Code Generation Analysis

## Pipeline

- Parsed components: 9
- Retained components: 3
- Declared operations: 10
- Generated requests: 10
- Webhook event payloads: 0
- Objects: 33
- Canonical Rust objects: 33
- Canonical Rust items: 36
- Canonical property analysis rounds: 4
- Canonical items with lifetimes: 0
- Canonical items deriving Copy: 0
- Canonical items deriving Eq: 30
- Fields: 84
- Enum variants: 24
- Parsed dependency facts: 20
- Retained dependency facts: 20
- Expandable edges used for layout: true
- ID-only edges used for layout: false
- Lowered Rust crate dependencies contain cycles: false
- Crate inference warnings: 0

## Dependency facts

### By representation

- Direct: 8
- IdOnly: 10
- InContainer: 2

### By usage

- ModelField: 3
- RequestParam: 7
- RequestReturn: 10

## Crates

| Crate | Model components | Request components | Requests | Objects | Fields |
|---|---:|---:|---:|---:|---:|
| async-stripe-shared | 0 | 0 | 0 | 0 | 0 |
| async-stripe-v2 | 3 | 2 | 10 | 33 | 84 |
| async-stripe-webhook | 0 | 0 | 0 | 0 | 0 |

## Represented model modules

- Model modules: 3
- Canonical declarations in model modules: 20
- Struct fields in model modules: 42
- Enum variants in model modules: 19
- Cross-module model dependencies: 0
- Strongly connected components: 3
- Components containing cross-module cycles: 0
- Largest component: 1 modules

These follow represented declaration and request type uses after placement. The model graph excludes request modules, webhook modules, ID-only modules, and intra-module references; isolated model modules are retained. `model-module-dependencies.csv` also includes the excluded edges.

SCC module/item/field/variant counts cover the entire component and repeat for each membership row. Counts use canonical declarations once, rather than inferred occurrences, and exclude generated helper declarations and implicit unknown variants. The reports do not include facade reexports, handwritten code, or feature activation, and do not measure a consumer's compiled source closure.
