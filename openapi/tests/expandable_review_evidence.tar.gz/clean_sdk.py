from pathlib import Path
import json, os, subprocess

base = Path("/private/tmp/async-stripe-codegen-review-20261108")
workspace = base / "full-v1/workspace"
env = dict(os.environ, CARGO_TARGET_DIR=str(base / "sdk-target"))
metadata = json.loads(subprocess.check_output(
    ["cargo", "+1.89.0", "metadata", "--offline", "--no-deps", "--format-version", "1"],
    cwd=workspace, env=env, text=True))
command = ["cargo", "+1.89.0", "clean", "--offline"]
for package in metadata["packages"]:
    command += ["-p", package["name"]]
subprocess.run(command, cwd=workspace, env=env, check=True)
for name in ["opaque-consumer", "opaque-webhook-consumer"]:
    subprocess.run(["cargo", "+1.89.0", "clean", "--offline", "--manifest-path",
                    str(workspace / "openapi/tests/fixtures" / name / "Cargo.toml"), "-p", name],
                   cwd=workspace, env=env, check=True)
