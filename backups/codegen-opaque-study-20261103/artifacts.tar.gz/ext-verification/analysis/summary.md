# Code Generation Analysis

## Pipeline

- Parsed components: 1470
- Retained components: 1464
- Declared operations: 578
- Generated requests: 547
- Webhook event payloads: 265
- Objects: 6722
- Canonical Rust objects: 6722
- Canonical Rust items: 6859
- Canonical property analysis rounds: 6
- Canonical items with lifetimes: 0
- Canonical items deriving Copy: 538
- Canonical items deriving Eq: 6183
- Fields: 16425
- Enum variants: 20654
- Parsed dependency facts: 3551
- Retained dependency facts: 3543
- Expandable edges used for layout: true
- ID-only edges used for layout: false
- Lowered Rust crate dependencies contain cycles: false
- Crate inference warnings: 0

## Dependency facts

### By representation

- Direct: 918
- Expandable: 326
- IdOnly: 477
- InContainer: 1748
- UnionMember: 74

### By usage

- ModelField: 2385
- RequestParam: 318
- RequestReturn: 562
- WebhookPayload: 278

## Crates

| Crate | Model components | Request components | Requests | Objects | Fields |
|---|---:|---:|---:|---:|---:|
| async-stripe-billing | 164 | 26 | 127 | 1051 | 2732 |
| async-stripe-checkout | 98 | 1 | 6 | 501 | 862 |
| async-stripe-connect | 94 | 14 | 51 | 469 | 1601 |
| async-stripe-core | 249 | 22 | 82 | 1628 | 3799 |
| async-stripe-fraud | 34 | 5 | 15 | 82 | 213 |
| async-stripe-issuing | 88 | 8 | 48 | 385 | 1037 |
| async-stripe-misc | 125 | 23 | 71 | 715 | 1340 |
| async-stripe-payment | 363 | 9 | 39 | 1168 | 2474 |
| async-stripe-product | 18 | 8 | 34 | 101 | 387 |
| async-stripe-reserve | 8 | 0 | 0 | 17 | 50 |
| async-stripe-shared | 112 | 0 | 0 | 180 | 840 |
| async-stripe-terminal | 48 | 5 | 28 | 156 | 464 |
| async-stripe-treasury | 63 | 10 | 46 | 262 | 626 |
| async-stripe-webhook | 0 | 0 | 0 | 7 | 0 |

## Represented model modules

- Active model modules: 1454
- Cross-module model dependencies: 926
- Strongly connected components: 1454
- Components containing cross-module cycles: 0
- Largest component: 1 modules

These use the same module dependencies as feature availability, after representation and placement. Request modules, reference-only modules, disabled modules, and intra-module references are excluded from the model graph. Singleton components are retained.

`model-module-dependencies.csv` includes the complete availability graph. `model-group-closures.csv` reports always-on modules separately from conditional feature closures; shared conditional modules occur in every requiring group and must not be summed. Counts cover declaration/request emission modules, not handwritten files or module index files.

- Facade extension decoder methods: 694

`record-decoders.csv` records optional field methods emitted in the public facade. Receiver and payload models may occupy different crates; these methods do not create dependencies between model crates.
