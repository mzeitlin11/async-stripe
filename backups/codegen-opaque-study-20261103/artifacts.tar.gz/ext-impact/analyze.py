from pathlib import Path
import csv,json,collections,subprocess
ROOT=Path(__file__).resolve().parents[1];OUT=Path(__file__).resolve().parent
before=ROOT/'broad-verification/analysis';after=ROOT/'ext-verification/analysis'
def rows(p,n):return list(csv.DictReader((p/n).open()))
old_items={r['item_id']:r for r in rows(before,'items.csv')};new_items={r['item_id']:r for r in rows(after,'items.csv')}
assert old_items.keys()==new_items.keys()
for i,a in old_items.items():
 b=new_items[i]
 assert all(a[k]==b[k] for k in ['origin','ident','kind','usage','has_lifetime','is_copy','is_eq','sharing_rule'])
for name in ['item-occurrences.csv','dependencies.csv']:assert (before/name).read_bytes()==(after/name).read_bytes()
shapes_old=json.loads((ROOT/'compiled-shape-analysis/after-shapes.json').read_text());shapes_new=json.loads((OUT/'model-shapes.json').read_text())
scenarios={}
for label,path,items,shapes in [('before',before,old_items,shapes_old),('after',after,new_items,shapes_new)]:
 components=rows(path,'components.csv');component_counts=collections.Counter(r['types_crate'] for r in components)
 totals=collections.defaultdict(collections.Counter);sites=collections.defaultdict(set)
 for item in items.values():
  source=item['emission_path']
  if not source.startswith('crates/') or source.endswith('/requests.rs') or item['kind']=='IdNewtype':continue
  if item['kind']=='OpaqueObject' and item['origin'].startswith('component:'):continue
  crate=Path(source).parts[1];shape=shapes[source.replace('crates/','generated/',1)][item['ident']]
  sites[crate].add(source)
  total=totals[crate];total['declarations']+=1
  if item['kind']=='Struct':total['fields']+=shape['fields'];total['structs']+=1
  elif item['kind']=='OpaqueRecord':total['fields']+=1;total['raw_record_wrappers']+=1
  elif item['kind'] in {'Enum','FieldlessEnum'}:total['enum_variants']+=shape['variants'];total['enums']+=1
 for crate in totals:totals[crate]['model_modules']=len(sites[crate]);totals[crate]['schema_components']=component_counts[crate]
 scenarios[label]={k:dict(v) for k,v in sorted(totals.items())}
 assert sum(v['model_modules'] for v in scenarios[label].values())==1460
 # Pure-record wrappers are counted as models here on both sides for comparable totals.
for i,item in new_items.items():
 if not item['emission_path'].startswith('crates/'):continue
 old=old_items[i]
 a=shapes_old[old['emission_path'].replace('crates/','generated/',1)][old['ident']]
 b=shapes_new[item['emission_path'].replace('crates/','generated/',1)][item['ident']]
 assert a==b,(i,a,b)
report={'baseline_commit':'41cf3d3f985899afafb4fcee920a8c6e149cc14b','canonical_items_unchanged':len(old_items),'stored_shapes_and_original_provenance_unchanged':True,'scenarios':scenarios,'extension_methods':len(rows(after,'record-decoders.csv')),'extension_traits':len({r['trait'] for r in rows(after,'record-decoders.csv')}),'model_graph_cycles':sum(r['cross_module_cycle']=='true' for r in rows(after,'model-module-sccs.csv')),'pure_record_accounting':'Six unchanged raw record wrappers are counted as model modules on both sides, although the new availability analysis categorizes them as reference support.','full_verification':json.loads((ROOT/'ext-verification/summary.json').read_text()),'narrow_verification':json.loads((ROOT/'ext-narrow-verification/summary.json').read_text()),'timings':json.loads((OUT/'compile-comparison.json').read_text())}
(OUT/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
with (OUT/'crates.csv').open('w',newline='') as f:
 fields=['crate','before_schema_components','schema_components','before_model_modules','model_modules','before_fields','fields','before_enum_variants','enum_variants'];w=csv.DictWriter(f,fieldnames=fields,lineterminator='\n');w.writeheader()
 for crate in scenarios['before']:
  a,b=scenarios['before'][crate],scenarios['after'][crate]
  w.writerow({'crate':crate,'before_schema_components':a['schema_components'],'schema_components':b['schema_components'],'before_model_modules':a['model_modules'],'model_modules':b['model_modules'],'before_fields':a['fields'],'fields':b['fields'],'before_enum_variants':a['enum_variants'],'enum_variants':b['enum_variants']})
print('Shared before:',scenarios['before']['async-stripe-shared'])
print('Shared after:',scenarios['after']['async-stripe-shared'])
print('Methods/traits:',report['extension_methods'],report['extension_traits'])
