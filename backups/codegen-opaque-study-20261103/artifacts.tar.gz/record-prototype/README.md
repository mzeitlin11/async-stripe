Staged runtime implementation; repository source is unchanged.

Copy async-stripe-types/src/record_value.rs and its tests.rs submodule into the matching repository paths, then apply integration.patch. The patch registers/exports RecordValue and RecordDecodeError and makes the existing JSON-object collector delegate envelope validation to T::from_value. ObjectValue still validates its id/object invariant.

The async-stripe facade should additionally reexport RecordDecodeError and RecordValue alongside ObjectDecodeError/ObjectValue in its existing stripe_types export list. No new Cargo dependencies or features are needed.

Generated code uses stripe_types::def_record_value!(PaymentMethodDetails). Typed accessors in decoder modules can call self.field_as("card") without accessing a private field. RecordValue and nominal wrappers expose type_(), as_value(), into_value(), and field_as(). They implement Clone/Debug, serde::Serialize, miniserde::Deserialize, FromValueOpt, and serde::Deserialize when enabled.

Parsing requires a JSON object with string type. Missing/null selected fields return None. Other selected fields are decoded fallibly using only a clone of that subtree. The record remains immutable and repeated calls decode again. Access follows field presence independently of type. Unknown types/fields remain intact. No Object/ObjectType implementations, feature-dependent storage, registry, or cache are introduced.

Tests cover absent identity, ObjectValue invariant retention through the generalized collector, unknown fields and large integers, repeated borrowed access, field/tag independence, malformed field deferral, malformed envelopes, eager/field decoder agreement, serde/miniserde parity, and raw/nominal debug redaction. They have been formatted but not built or run, per the baseline verification freeze.
