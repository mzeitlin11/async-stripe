// Metadata-only optional feature resolution probe.
