#!/usr/bin/env python3
"""Exploratory local Core API compilation comparison; no SDK source edits."""
from pathlib import Path
import json,os,statistics,subprocess,time,runpy,sys,shutil
ROOT=Path(__file__).resolve().parents[1]
OUT=Path(__file__).resolve().parent
flags=json.loads((OUT/'summary.json').read_text())['core_resource_features']
workspaces={'before':ROOT/'consumer-verification/workspace','after':ROOT/'broad-verification/workspace'}
env=dict(os.environ,CARGO_TARGET_DIR=str(ROOT/'broad-bindings-target'),CARGO_PROFILE_DEV_DEBUG='0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2')
# Execute a read-only helper without creating a product-tree __pycache__.
sys.dont_write_bytecode=True
helper=runpy.run_path(str(ROOT/'worktree/openapi/tests/verify_opaque_groups.py'))['compiled_generated_sources']
for name,workspace in workspaces.items():
 probe=OUT/'probes'/name
 (probe/'src').mkdir(parents=True,exist_ok=True)
 manifest='[package]\nname = "core-size-probe"\nversion = "0.0.0"\nedition = "2024"\npublish = false\n\n[workspace]\n\n[dependencies]\nstripe = { package = "async-stripe", path = '+json.dumps(str(workspace/'async-stripe'))+', default-features = false, features = '+json.dumps(flags)+' }\n'
 (probe/'Cargo.toml').write_text(manifest)
 (probe/'src/lib.rs').write_text('pub fn require_core_models() { let _ = core::mem::size_of::<stripe::Customer>(); let _ = core::mem::size_of::<stripe::PaymentIntent>(); let _ = core::mem::size_of::<stripe::Charge>(); }\n')
 shutil.copyfile(workspace/'Cargo.lock',probe/'Cargo.lock')
if '--prepare-only' in sys.argv:
 print('Prepared identical Core feature probes:',len(flags),'features')
 raise SystemExit(0)

def run(name,kind,iteration):
 workspace=workspaces[name];probe=OUT/'probes'/name
 command=['cargo','+1.89.0','check','--offline','--message-format=json']
 start=time.perf_counter();result=subprocess.run(command,cwd=probe,env=env,text=True,capture_output=True);elapsed=time.perf_counter()-start
 (OUT/f'compile-{name}-{iteration}-{kind}.log').write_text(result.stderr)
 assert result.returncode==0,(name,result.stderr[-6000:])
 sources=helper(result.stdout,workspace)
 (OUT/f'{name}-compiled-sources.json').write_text(json.dumps(sources,indent=2)+'\n')
 return {'scenario':name,'kind':kind,'iteration':iteration,'seconds':elapsed,'generated_source_files':len(sources)}

packages={}
for name,workspace in workspaces.items():
 probe=OUT/'probes'/name
 result=subprocess.run(['cargo','+1.89.0','metadata','--offline','--format-version','1'],cwd=probe,env=env,text=True,capture_output=True,check=True)
 metadata=json.loads(result.stdout)
 packages[name]=sorted({p['name'] for p in metadata['packages'] if str(p['manifest_path']).startswith(str(workspace)) or p['name']=='core-size-probe'})
 print('Warming',name,flush=True);run(name,'warmup',0)
results=[]
for iteration,order in enumerate([['before','after'],['after','before']],1):
 for name in order:
  clean=['cargo','+1.89.0','clean']
  for package in packages[name]:clean+=['-p',package]
  subprocess.run(clean,cwd=OUT/'probes'/name,env=env,capture_output=True,check=True)
  for kind in ['project-clean','warm']:
   result=run(name,kind,iteration);results.append(result);print(json.dumps(result),flush=True)
summary={'toolchain':'1.89.0','command':'cargo check','core_features':flags,'profile':'debug=0; incremental=false; jobs=2','method':'Warm both dependency graphs, then two alternating before/after runs. Clean all resolved SDK path packages and probe before each project-clean check; retain registry/build dependencies. Warm checks immediately follow. Exploratory local timings on one machine, not a controlled benchmark.','cleaned_packages':packages,'runs':results,'medians':{name:{kind:statistics.median(r['seconds'] for r in results if r['scenario']==name and r['kind']==kind) for kind in ['project-clean','warm']} for name in workspaces}}
(OUT/'compile-comparison.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary['medians'],indent=2),flush=True)
