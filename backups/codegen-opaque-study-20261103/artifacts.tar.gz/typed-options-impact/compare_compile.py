#!/usr/bin/env python3
"""Full API+decoder+serde check comparison with per-crate Cargo timings."""
from pathlib import Path
import json,os,statistics,subprocess,time,runpy,sys,shutil,re
ROOT=Path(__file__).resolve().parents[1];OUT=Path(__file__).resolve().parent
flags=['full','serialize','deserialize']
workspaces={'before':ROOT/'ext-verification/workspace','after':ROOT/'typed-options-verification/workspace'}
env=dict(os.environ,CARGO_TARGET_DIR=str(ROOT/'typed-options-target'),CARGO_PROFILE_DEV_DEBUG='0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='4')
sys.dont_write_bytecode=True
helper=runpy.run_path(str(ROOT/'worktree/openapi/tests/verify_opaque_groups.py'))['compiled_generated_sources']
for name,workspace in workspaces.items():
 probe=OUT/'probes'/name;(probe/'src').mkdir(parents=True,exist_ok=True)
 manifest='[package]\nname = "all-models-probe"\nversion = "0.0.0"\nedition = "2024"\npublish = false\n\n[workspace]\n\n[dependencies]\nstripe = { package = "async-stripe", path = '+json.dumps(str(workspace/'async-stripe'))+', default-features = false, features = '+json.dumps(flags)+' }\n'
 (probe/'Cargo.toml').write_text(manifest)
 (probe/'src/lib.rs').write_text('pub fn require_models() { let _ = core::mem::size_of::<stripe::Customer>(); let _ = core::mem::size_of::<stripe::PaymentIntent>(); let _ = core::mem::size_of::<stripe::Charge>(); }\n')
 shutil.copyfile(workspace/'Cargo.lock',probe/'Cargo.lock')
if '--prepare-only' in sys.argv:print('Prepared full-feature probes');raise SystemExit(0)

def run(name,kind,iteration):
 probe=OUT/'probes'/name
 start=time.perf_counter();r=subprocess.run(['cargo','+1.89.0','check','--offline','--timings','--message-format=json'],cwd=probe,env=env,text=True,capture_output=True);elapsed=time.perf_counter()-start
 (OUT/f'compile-{name}-{iteration}-{kind}.log').write_text(r.stderr)
 assert r.returncode==0,(name,r.stderr[-6000:])
 html=(ROOT/'typed-options-target/cargo-timings/cargo-timing.html').read_text()
 match=re.search(r'(?:const|let) UNIT_DATA\s*=\s*(\[.*?\]);',html,re.S)
 assert match, 'Cargo timing UNIT_DATA format not recognized; see saved timing HTML'
 units=json.loads(match.group(1))
 (OUT/f'timing-{name}-{iteration}-{kind}.json').write_text(json.dumps(units,indent=2)+'\n')
 sources=helper(r.stdout,workspaces[name]);(OUT/f'{name}-compiled-sources.json').write_text(json.dumps(sources,indent=2)+'\n')
 project=[u for u in units if u['name'].startswith('async-stripe') or u['name']=='all-models-probe']
 result={'scenario':name,'kind':kind,'iteration':iteration,'seconds':elapsed,'generated_source_files':len(sources),'crate_seconds':{u['name']:u['duration'] for u in project},'crate_start_seconds':{u['name']:u['start'] for u in project},'crate_rmeta_seconds':{u['name']:u.get('rmeta_time') for u in project}}
 print(json.dumps(result),flush=True);return result
packages={}
for name,workspace in workspaces.items():
 probe=OUT/'probes'/name
 metadata=json.loads(subprocess.run(['cargo','+1.89.0','metadata','--offline','--format-version','1'],cwd=probe,env=env,text=True,capture_output=True,check=True).stdout)
 packages[name]=sorted({p['name'] for p in metadata['packages'] if str(p['manifest_path']).startswith(str(workspace)) or p['name']=='all-models-probe'})
 print('Warming '+name,flush=True);run(name,'warmup',0)
results=[]
for iteration,order in enumerate([['before','after'],['after','before']],1):
 for name in order:
  cmd=['cargo','+1.89.0','clean']
  for package in packages[name]:cmd+=['-p',package]
  subprocess.run(cmd,cwd=OUT/'probes'/name,env=env,capture_output=True,check=True)
  results.append(run(name,'project-clean',iteration))
summary={'toolchain':'1.89.0','command':'cargo check --timings','features':flags,'profile':'debug=0; incremental=false; jobs=4','method':'Warm both graphs, then two alternating before/after rounds. Clean all resolved SDK path packages and probe before each check; retain registry/build dependencies. Exploratory local measurements on one machine.','cleaned_packages':packages,'runs':results,'medians':{name:{'wall_seconds':statistics.median(r['seconds'] for r in results if r['scenario']==name),'crate_seconds':{p:statistics.median(r['crate_seconds'][p] for r in results if r['scenario']==name and p in r['crate_seconds']) for p in packages[name]}} for name in workspaces}}
(OUT/'compile-comparison.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary['medians'],indent=2),flush=True)
