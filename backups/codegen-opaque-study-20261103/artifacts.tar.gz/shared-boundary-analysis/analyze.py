#!/usr/bin/env python3
"""Explain the existing consumer placement without changing SDK or generator sources."""
import collections,csv,json,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
ANALYSIS=ROOT/'consumer-verification/analysis'
OUT=Path(__file__).resolve().parent
SHARED='async-stripe-shared'
def rows(name):
 with (ANALYSIS/name).open(newline='') as f:return list(csv.DictReader(f))
components={r['component']:r for r in rows('components.csv')}
items=rows('items.csv')
by_site=collections.defaultdict(list)
roots={}
for item in items:
 by_site[item['emission_path']].append(item)
 name=item['origin'].removeprefix('component:')
 if item['origin'].startswith('component:') and name in components and item['ident']==components[name]['ident']:roots[name]=item
assert roots.keys()==components.keys()
modules={}
for name,item in roots.items():
 path=Path(item['emission_path']);mod=path.parent.name if path.name=='types.rs' else path.stem
 assert mod not in modules,mod
 modules[mod]=name
features=[r['group'] for r in rows('model-group-closures.csv') if r['scope']=='feature']
assert all(f in modules for f in features)
feature_domains={f:components[modules[f]]['request_crate'] for f in features}
availability={r['emission_path']:r['availability'] for r in rows('model-availability.csv')}
edges=set()
for r in rows('model-module-dependencies.csv'):
 source,target=r['source_emission_path'],r['target_emission_path']
 edges.add((source,target));availability.setdefault(source,r['source_availability']);availability.setdefault(target,r['target_availability'])
colocations=rows('model-colocations.csv')
colocation_edges={(r['owner_emission_path'],r['payload_emission_path']) for r in colocations}|{(r['payload_emission_path'],r['owner_emission_path']) for r in colocations}
graph=collections.defaultdict(set)
for source,target in edges:graph[source].add(target)
def closure(seeds, successors=graph):
 seen=set();pending=list(seeds)
 while pending:
  site=pending.pop()
  if site not in seen:seen.add(site);pending.extend(successors[site]-seen)
 return seen
model_domains=collections.defaultdict(set)
for feature in features:
 domain=feature_domains[feature]
 for site in closure([roots[modules[feature]]['emission_path']]):
  if availability[site] not in {'always','disabled'}:model_domains[site].add(domain)

full_domains={site:({feature_domains[f] for f in condition.split('|')} if condition not in {'always','disabled'} else set()) for site,condition in availability.items()}
# Accessor receiver references are emitted dependencies but do not store data.
receiver_edges={(r['payload_emission_path'],r['owner_emission_path']) for r in colocations}
storage_graph=collections.defaultdict(set)
for source,target in edges-receiver_edges:storage_graph[source].add(target)
stored_domains=collections.defaultdict(set)
reconstructed_domains=collections.defaultdict(set)
for feature in features:
 domain=feature_domains[feature];component=modules[feature]
 seeds=[roots[component]['emission_path']]
 request=f"crates/{domain}/src/{feature}/requests.rs"
 if request in availability:seeds.append(request)
 for site in closure(seeds):
  if availability[site] not in {'always','disabled'}:reconstructed_domains[site].add(domain)
 for site in closure(seeds,storage_graph):
  if availability[site] not in {'always','disabled'}:stored_domains[site].add(domain)
assert all(reconstructed_domains[site]==full_domains[site] for site in availability)
facade_domains=collections.defaultdict(set)
for item in items:
 prefix=next((p for p in ['component:','object-id:'] if item['origin'].startswith(p)),None)
 if prefix is None:continue
 name=item['origin'][len(prefix):]
 if name in components and (prefix=='object-id:' or item['ident']==components[name]['ident']):facade_domains[item['emission_path']].add(components[name]['request_crate'])

def simulate(exports=True,colocate=True,requests=True):
 users={s:set(full_domains[s] if requests else model_domains[s]) for s in availability}
 for site,condition in availability.items():
  request=site.endswith('/requests.rs')
  if request and requests:
   users[site].add(Path(site).parts[1])
  if condition in {'always','disabled'} and not request:users[site].add(SHARED)
  for item in by_site[site]:
   if item['kind']=='IdNewtype' or (item['kind']=='OpaqueObject' and item['origin'].removeprefix('component:') in roots) or item['origin'].startswith('shared:'):users[site].add(SHARED)
  if exports:users[site].update(facade_domains[site])
 propagation=edges|(colocation_edges if colocate else set())
 if not requests:propagation={(s,t) for s,t in propagation if not s.endswith('/requests.rs')}
 while True:
  changed=False
  for source,target in sorted(propagation):
   extra=users[source]-users[target]
   if extra:users[target].update(extra);changed=True
  if not changed:break
 assigned={name:next(iter(users[root['emission_path']])) if len(users[root['emission_path']])==1 else SHARED for name,root in roots.items()}
 return users,assigned
actual_users,actual=simulate()
assert all(actual[n]==c['types_crate'] for n,c in components.items()),[(n,actual[n],c['types_crate']) for n,c in components.items() if actual[n]!=c['types_crate']]
no_export_users,no_exports=simulate(exports=False)
no_colo_users,no_colo=simulate(colocate=False)
model_users,model_assignments=simulate(requests=False)
shared=sorted(n for n in roots if actual[n]==SHARED)
record_sites={r['owner_emission_path'] for r in colocations}|{r['payload_emission_path'] for r in colocations}
classified=[]
for name in shared:
 site=roots[name]['emission_path'];direct=full_domains[site]
 if availability[site]=='always':reason='unconditional support'
 elif len(direct)>1:reason='multiple domains reach through emitted types or requests'
 elif no_exports[name]!=SHARED:reason='retained domain exports make shared necessary'
 elif no_colo[name]!=SHARED:reason='inherent accessor colocation makes shared necessary'
 else:reason='dependency propagation from shared or colocated consumers'
 classified.append(dict(component=name,ident=components[name]['ident'],kind=roots[name]['kind'],availability=availability[site],reason=reason,original_domain=components[name]['request_crate'],direct_domains='|'.join(sorted(direct)),stored_data_or_request_domains='|'.join(sorted(stored_domains[site])),model_only_domains='|'.join(sorted(model_domains[site])),retained_export_domains='|'.join(sorted(facade_domains[site])),effective_domains='|'.join(sorted(actual_users[site])),without_retained_exports=no_exports[name],without_inherent_colocation=no_colo[name],without_http_consumption=model_assignments[name],in_accessor_colocation=site in record_sites,emission_path=site))
with (OUT/'shared-components.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(classified[0]),lineterminator='\n');w.writeheader();w.writerows(classified)

# Incoming source modules supply short, inspectable examples of actual eager uses.
incoming=collections.defaultdict(set)
for source,target in edges:
 if source!=target:incoming[target].add(source)
def site_names(site):
 names=[n for n,r in roots.items() if r['emission_path']==site]
 return names or [site]
def witness(site,domain):
 # BFS gives an actual type/request dependency path from a feature root.
 initial=[]
 for feature,owner in feature_domains.items():
  if owner!=domain:continue
  component=modules[feature];root=roots[component]['emission_path']
  initial.append((root,feature,'model'))
  request=f"crates/{owner}/src/{feature}/requests.rs"
  if request in availability:initial.append((request,feature,'request'))
 queue=collections.deque((s,f,k,[s]) for s,f,k in initial);seen=set()
 while queue:
  node,feature,kind,path=queue.popleft()
  if node==site:return {'feature':feature,'root_kind':kind,'path':path,'components':[site_names(s) for s in path]}
  if node in seen:continue
  seen.add(node)
  for target in sorted(graph[node]):queue.append((target,feature,kind,path+[target]))
 return None
selected=['payment_method','payment_method_details','price','plan','subscription','subscription_item','issuing.card','issuing.authorization','balance_transaction','file','bank_account','card','source','tax_id','tax_rate','shipping']
examples=[]
for name in selected:
 if name not in roots:continue
 site=roots[name]['emission_path']
 examples.append({'component':name,'placement':actual[name],'direct_domains':sorted(full_domains[site]),'effective_domains':sorted(actual_users[site]),'without_retained_exports':no_exports[name],'without_colocation':no_colo[name],'without_http_consumption':model_assignments[name],'incoming_modules':[{'path':s,'components':site_names(s)} for s in sorted(incoming[site])],'witnesses':{d:witness(site,d) for d in sorted(full_domains[site])}})
conditional_shared=[r for r in classified if r['availability']!='always']
result={
 'source_commit':'4b8a58a62d09fcf9bed41e1fd9bf747b4587b542',
 'shared_components':len(shared),
 'reproduces_actual_placement':True,
 'reason_counts':dict(collections.Counter(r['reason'] for r in classified)),
 'shared_with_multiple_stored_data_or_request_domains':sum(len(stored_domains[roots[n]['emission_path']])>1 for n in shared),
 'accessor_receiver_domains':{'component':'payment_method_details','stored_data_or_request_domains':sorted(stored_domains[roots['payment_method_details']['emission_path']]),'emitted_domains':sorted(full_domains[roots['payment_method_details']['emission_path']]),'stored_incoming_modules':sorted(source for source,targets in storage_graph.items() if roots['payment_method_details']['emission_path'] in targets and source!=roots['payment_method_details']['emission_path'])},
 'shared_component_original_domains':dict(collections.Counter(r['original_domain'] for r in classified)),
 'conditional_shared_components':len(conditional_shared),
 'always_shared_components':[r['component'] for r in classified if r['availability']=='always'],
 'shared_components_without_exports':sum(v==SHARED for v in no_exports.values()),
 'shared_components_that_would_move_without_exports':[n for n in shared if no_exports[n]!=SHARED],
 'shared_components_that_would_move_without_inherent_colocation':[n for n in shared if no_colo[n]!=SHARED],
 'shared_components_that_would_move_without_http_consumption':[n for n in shared if model_assignments[n]!=SHARED],
 'counterfactual_limits':{'without_exports':'Diagnostic only; existing domain imports would need redesign.','without_colocation':'Not valid with current inherent accessor API; Rust requires receiver and inherent methods in the same crate.','without_http_consumption':'Diagnostic model-only workload; not a proposed SDK layout. Request and response models are still part of the real SDK.'},
 'examples':examples,
 'conditional_model_closures':{name:{'components':len([n for n,r in roots.items() if r['emission_path'] in closure([roots[name]['emission_path']]) and availability[r['emission_path']]!='always']),'shared_components':len([n for n,r in roots.items() if r['emission_path'] in closure([roots[name]['emission_path']]) and availability[r['emission_path']]!='always' and actual[n]==SHARED])} for name in ['payment_method','source','confirmation_token','payment_method_details','subscription','price','issuing.card','charge']},
 'opaque_items':[{'ident':r['ident'],'kind':r['kind'],'origin':r['origin'],'emission_path':r['emission_path']} for r in items if r['kind'] in {'OpaqueObject','OpaqueRecord'}],
 'inputs_sha256':{n:hashlib.sha256((ANALYSIS/n).read_bytes()).hexdigest() for n in ['components.csv','items.csv','model-availability.csv','model-module-dependencies.csv','model-colocations.csv','model-group-closures.csv']},
}
(OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['shared_components','reason_counts','shared_with_multiple_stored_data_or_request_domains','accessor_receiver_domains','conditional_model_closures']},indent=2))
