pub fn require_core_models() { let _ = core::mem::size_of::<stripe::Customer>(); let _ = core::mem::size_of::<stripe::PaymentIntent>(); let _ = core::mem::size_of::<stripe::Charge>(); }
