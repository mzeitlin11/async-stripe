from pathlib import Path
import csv,json,collections
ROOT=Path(__file__).resolve().parents[1];OUT=Path(__file__).resolve().parent
old=ROOT/'ext-verification/analysis';new=ROOT/'typed-options-verification/analysis'
def rows(p,n):return list(csv.DictReader((p/n).open()))
old_items={r['item_id']:r for r in rows(old,'items.csv')};new_items={r['item_id']:r for r in rows(new,'items.csv')}
assert old_items.keys()==new_items.keys()
for i,a in old_items.items():
 assert all(a[k]==new_items[i][k] for k in ['origin','ident','kind','usage','sharing_rule'])
for name in ['item-occurrences.csv','dependencies.csv']:assert (old/name).read_bytes()==(new/name).read_bytes()
old_shapes=json.loads((ROOT/'ext-impact/model-shapes.json').read_text());new_shapes=json.loads((OUT/'model-shapes.json').read_text())
changes=[]
for i,a in old_items.items():
 b=new_items[i]
 if not a['emission_path'].startswith('crates/'):continue
 sa=old_shapes[a['emission_path'].replace('crates/','generated/',1)][a['ident']]
 sb=new_shapes[b['emission_path'].replace('crates/','generated/',1)][b['ident']]
 if sa!=sb:changes.append({'item_id':i,'ident':a['ident'],'before':sa,'after':sb})
assert len(changes)==6,changes
scenarios={}
for label,path,items,shapes in [('before',old,old_items,old_shapes),('after',new,new_items,new_shapes)]:
 counts=collections.Counter(r['types_crate'] for r in rows(path,'components.csv'));totals=collections.defaultdict(collections.Counter);sites=collections.defaultdict(set)
 for item in items.values():
  p=item['emission_path']
  if not p.startswith('crates/') or p.endswith('/requests.rs') or item['kind']=='IdNewtype':continue
  if item['kind']=='OpaqueObject' and item['origin'].startswith('component:'):continue
  crate=Path(p).parts[1];s=shapes[p.replace('crates/','generated/',1)][item['ident']];sites[crate].add(p);t=totals[crate];t['declarations']+=1
  if item['kind']=='Struct':t['fields']+=s['fields']
  elif item['kind']=='OpaqueRecord':t['fields']+=1
  elif item['kind'] in {'Enum','FieldlessEnum'}:t['enum_variants']+=s['variants']
 for crate,t in totals.items():t['schema_components']=counts[crate];t['model_modules']=len(sites[crate])
 scenarios[label]={k:dict(v) for k,v in sorted(totals.items())}
feature_closures=[]
bc={r['group']:r for r in rows(old,'model-group-closures.csv') if r['scope']=='feature'}
ac={r['group']:r for r in rows(new,'model-group-closures.csv') if r['scope']=='feature'}
for feature in sorted(bc.keys()&ac.keys()):
 b,a=bc[feature],ac[feature]
 if a['model_modules']!=b['model_modules']:feature_closures.append({'feature':feature,'before_model_modules':int(b['model_modules']),'model_modules':int(a['model_modules'])})
report={'baseline_commit':'b00b58b3b8318516db14571293e18c0046f2a4f5','canonical_items_preserved':len(old_items),'original_semantics_and_provenance_unchanged':True,'changed_record_shapes':changes,'scenarios':scenarios,'changed_feature_closures':feature_closures,'extension_methods':len(rows(new,'record-decoders.csv')),'extension_traits':len({r['trait'] for r in rows(new,'record-decoders.csv')}),'model_graph_cycles':sum(r['cross_module_cycle']=='true' for r in rows(new,'model-module-sccs.csv'))}
(OUT/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
with (OUT/'changed-feature-closures.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['feature','before_model_modules','model_modules'],lineterminator='\n');w.writeheader();w.writerows(feature_closures)
print('Shared before:',scenarios['before']['async-stripe-shared'])
print('Shared after:',scenarios['after']['async-stripe-shared'])
print('Changed DTOs:',[c['ident'] for c in changes])
