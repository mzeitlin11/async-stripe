# Code Generation Analysis

## Pipeline

- Parsed components: 147
- Retained components: 10
- Declared operations: 25
- Generated requests: 25
- Webhook event payloads: 0
- Objects: 802
- Canonical Rust objects: 802
- Canonical Rust items: 809
- Canonical property analysis rounds: 5
- Canonical items with lifetimes: 0
- Canonical items deriving Copy: 130
- Canonical items deriving Eq: 782
- Fields: 2213
- Enum variants: 1026
- Parsed dependency facts: 51
- Retained dependency facts: 51
- Expandable edges used for layout: true
- ID-only edges used for layout: false
- Lowered Rust crate dependencies contain cycles: false
- Crate inference warnings: 0

## Dependency facts

### By representation

- Direct: 21
- IdOnly: 26
- InContainer: 4

### By usage

- ModelField: 8
- RequestParam: 18
- RequestReturn: 25

## Crates

| Crate | Model components | Request components | Requests | Objects | Fields |
|---|---:|---:|---:|---:|---:|
| async-stripe-events | 2 | 0 | 0 | 21 | 46 |
| async-stripe-shared | 0 | 0 | 0 | 0 | 0 |
| async-stripe-v2 | 8 | 7 | 25 | 781 | 2167 |
| async-stripe-webhook | 0 | 0 | 0 | 0 | 0 |

## Represented model modules

- Model modules: 10
- Canonical declarations in model modules: 334
- Struct fields in model modules: 844
- Enum variants in model modules: 649
- Cross-module model dependencies: 0
- Strongly connected components: 10
- Components containing cross-module cycles: 0
- Largest component: 1 modules

These follow represented declaration and request type uses after placement. The model graph excludes request modules, webhook modules, ID-only modules, and intra-module references; isolated model modules are retained. `model-module-dependencies.csv` also includes the excluded edges.

SCC module/item/field/variant counts cover the entire component and repeat for each membership row. Counts use canonical declarations once, rather than inferred occurrences, and exclude generated helper declarations and implicit unknown variants. The reports do not include facade reexports, handwritten code, or feature activation, and do not measure a consumer's compiled source closure.
