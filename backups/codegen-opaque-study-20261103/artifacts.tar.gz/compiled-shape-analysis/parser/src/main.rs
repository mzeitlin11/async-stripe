use std::{collections::BTreeMap, env, fs, path::Path};
use serde_json::{Value, json};

fn analyze_items(items: &[syn::Item], out: &mut BTreeMap<String,Value>) {
    for item in items {
        let (name, shape) = match item {
            syn::Item::Struct(item) => (item.ident.to_string(),json!({
                "kind":"Struct", "fields":item.fields.len(),
                "public_fields":item.fields.iter().filter(|f| matches!(f.vis,syn::Visibility::Public(_))).count(),
                "variants":0,
                "raw_bags":item.fields.iter().filter(|f| f.ident.as_ref().is_some_and(|id| id=="variant_fields")).count(),
            })),
            syn::Item::Enum(item) => (item.ident.to_string(),json!({
                "kind":"Enum", "fields":item.variants.iter().map(|v|v.fields.len()).sum::<usize>(),
                "public_fields":0, "variants":item.variants.len(), "raw_bags":0,
            })),
            syn::Item::Macro(item) => {
                let Some(last)=item.mac.path.segments.last() else {continue};
                let kind=match last.ident.to_string().as_str() {
                    "def_id"=>"IdNewtype", "def_object_value"=>"OpaqueObject", "def_record_value"=>"OpaqueRecord", _=>continue,
                };
                let name=item.mac.tokens.to_string();
                (name,json!({"kind":kind,"fields":0,"public_fields":0,"variants":0,"raw_bags":0}))
            }
            syn::Item::Mod(item) => {
                if let Some((_,items))=&item.content {analyze_items(items,out)}
                continue;
            }
            _=>continue,
        };
        assert!(out.insert(name.clone(),shape).is_none(),"duplicate declaration {name}");
    }
}
fn walk(root:&Path,path:&Path,result:&mut BTreeMap<String,Value>) {
    let mut files=fs::read_dir(path).unwrap().map(|e|e.unwrap().path()).collect::<Vec<_>>();files.sort();
    for file in files {
        if file.is_dir() {walk(root,&file,result)}
        else if file.extension().is_some_and(|ext|ext=="rs") {
            let source=fs::read_to_string(&file).unwrap();
            let parsed=syn::parse_file(&source).unwrap_or_else(|e|panic!("{}: {e}",file.display()));
            let mut declarations=BTreeMap::new();analyze_items(&parsed.items,&mut declarations);
            result.insert(file.strip_prefix(root).unwrap().to_string_lossy().into_owned(),json!(declarations));
        }
    }
}
fn main() {
    let args=env::args().skip(1).collect::<Vec<_>>();
    assert_eq!(args.len(),2,"parser WORKSPACE OUTPUT_JSON");
    let root=Path::new(&args[0]);let mut result=BTreeMap::new();walk(root,&root.join("generated"),&mut result);
    fs::write(&args[1],serde_json::to_vec(&result).unwrap()).unwrap();
    println!("Parsed {} generated Rust files",result.len());
}
