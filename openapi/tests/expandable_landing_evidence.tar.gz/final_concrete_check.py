from pathlib import Path
import json, os, subprocess, sys, shutil

root = Path("/private/tmp/async-stripe-codegen-landing-20261108/worktree")
work = Path("/private/tmp/async-stripe-codegen-expandables-20261108")
assert json.loads((work / "sequential-verification.json").read_text())["all_passed"]
workspace = work / "concrete-verification/workspace"
target = Path("/private/tmp/async-stripe-neutral-refactor-20261107/sdk-target")
env = dict(os.environ, CARGO_TARGET_DIR=str(target), CARGO_PROFILE_DEV_DEBUG="0",
           CARGO_INCREMENTAL="0", CARGO_BUILD_JOBS="2", PYTHONDONTWRITEBYTECODE="1")
metadata = json.loads(subprocess.check_output(
    ["cargo", "+1.89.0", "metadata", "--offline", "--no-deps", "--format-version", "1"],
    cwd=workspace, env=env, text=True))
command = ["cargo", "+1.89.0", "clean", "--offline"]
for package in metadata["packages"]:
    command += ["-p", package["name"]]
with (work / "clean-before-final-concrete.log").open("w") as log:
    subprocess.run(command, cwd=workspace, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
shutil.copyfile(root / "async-stripe-webhook/src/webhook.rs", workspace / "async-stripe-webhook/src/webhook.rs")
for name, command in [
    ("concrete-customer-source-check", ["check", "--offline", "-p", "async-stripe-core", "--no-default-features", "--features", "customer", "--message-format=json"]),
    ("concrete-webhook-final", ["test", "--offline", "-p", "async-stripe-webhook", "--all-features"]),
]:
    with (work / f"{name}.log").open("w") as log:
        subprocess.run(["cargo", "+1.89.0", *command], cwd=workspace, env=env,
                       stdout=log, stderr=subprocess.STDOUT, check=True)
sys.dont_write_bytecode = True
sys.path.insert(0, str(root / "openapi/tests"))
from verify_generated_workspace import compiled_generated_sources
sources = compiled_generated_sources(work / "concrete-customer-source-check.log", workspace)
counts = json.loads((work / "concrete-physical-fields.json").read_text())["fields_by_file"]
totals = {}
for source in sources:
    if source in counts:
        package = source.split("/")[1]
        totals[package] = totals.get(package, 0) + counts[source]
(work / "concrete-customer-compiled-fields.json").write_text(json.dumps({
    "compiled_generated_sources": sources,
    "deserialization_fields_per_package": totals,
    "strict_compiler_source_check": True,
}, indent=2) + "\n")
print("Fresh concrete Customer compiled fields:", totals, flush=True)
