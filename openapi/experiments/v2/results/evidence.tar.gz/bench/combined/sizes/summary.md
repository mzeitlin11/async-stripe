# Compile benchmark

Complete. Commit: `a988ac66dcce313834c9e9457c5eb69a6e42fb01`. Target: `aarch64-apple-darwin`.

Repository: `/private/tmp/async-stripe-v2-study-20261103/artifact-study/combined/workspace`.

Collector: `0.0.0`; source SHA-256: `10ee043482585af87e2ca32a3345ebbd4bc8091b85e87ebda164445b45fd0c53`.

`rustc 1.89.0 (29483883e 2025-08-04)`. Platform: `macos/aarch64`. [Raw data](results.json).

| Workload | Profile | Executable | Stripped | Text sections | Debug sections | Stripe rlibs | Stripe rmeta |
|---|---|---:|---:|---:|---:|---:|---:|
| minimal | dev | 1.04 MB | 683.18 KB | 381.97 KB | 0 B | 55.03 MB | 12.98 MB |
| minimal | release | 617.10 KB | 427.28 KB | 265.74 KB | 0 B | 21.95 MB | 15.45 MB |

## Incremental caches

| Workload | Profile | Consumer | Stripe libraries |
|---|---|---:|---:|
| minimal | dev | 883.64 KB | 170.62 MB |

## Library artifacts

<details>
<summary>minimal/dev</summary>

| Library | rlib | rmeta | Features |
|---|---:|---:|---|
| async-stripe-client-core | 975.58 KB | 273.03 KB | uuid, v2 |
| async-stripe-types | 811.46 KB | 295.06 KB |  |
| async-stripe-v2 | 53.24 MB | 12.41 MB |  |

</details>

<details>
<summary>minimal/release</summary>

| Library | rlib | rmeta | Features |
|---|---:|---:|---|
| async-stripe-client-core | 412.05 KB | 312.56 KB | uuid, v2 |
| async-stripe-types | 413.23 KB | 324.76 KB |  |
| async-stripe-v2 | 21.13 MB | 14.81 MB |  |

</details>

## Retained artifacts

Paths are relative to this report directory. Full targets can include incomplete failed builds.

| Workload/profile | Build | Artifact | Path |
|---|---:|---|---|
| minimal/dev | 1 | executable | [artifacts/minimal-dev/executable](<artifacts/minimal-dev/executable>) |
| minimal/release | 1 | executable | [artifacts/minimal-release/executable](<artifacts/minimal-release/executable>) |

Build commands and explicit environment overrides are saved as `logs/<workload>-<profile>/build-<N>.command.json`. Inherited build inputs are recorded in `results.json`.
