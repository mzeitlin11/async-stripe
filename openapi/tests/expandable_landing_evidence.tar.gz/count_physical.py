from pathlib import Path
import re,json,sys

def fields(root):
 per_file={}
 for path in (root/'generated').rglob('*.rs'):
  text=path.read_text();names=set(re.findall(r'impl(?:<[^>]*>)?\s+(?:stripe_types::)?ObjectDeser\s+for\s+(\w+)',text));n=0
  for m in re.finditer(r'\bstruct\s+(\w+)(?:<[^>]*>)?\s*\{',text):
   if m[1] not in names:continue
   start=m.end();i=start;depth=1
   while depth:
    c=text[i]
    if c=='{':depth+=1
    if c=='}':depth-=1
    i+=1
   fs=re.findall(r'^\s*(?:pub(?:\([^)]*\))?\s+)?(\w+)\s*:(?!:)',text[start:i-1],re.M)
   n+=sum(name!='variant_fields' for name in fs)
  if n:per_file[str(path.relative_to(root))]=n
 totals={}
 for path,n in per_file.items():
  package=path.split('/')[1];totals[package]=totals.get(package,0)+n
 return per_file,dict(sorted(totals.items()))
work=Path('/private/tmp/async-stripe-codegen-expandables-20261108')
for mode,dir in [('concrete','concrete-verification'),('opaque','full-v1'),('consumer','consumer-layout')]:
 per_file,totals=fields(work/dir/'workspace')
 report={'method':'Struct fields for declarations implementing ObjectDeser, excluding private raw field bags. IDs, variants, builders, and request-only structs excluded.','fields_by_file':per_file,'fields_by_package':totals}
 (work/f'{mode}-physical-fields.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
 print(mode,totals,'total',sum(totals.values()))
 if mode!='concrete':
  manifest=json.loads((work/dir/'model_manifest.json').read_text());expected={}
  for row in manifest:
   path=row['path'].replace('crates/','generated/',1)
   if path.startswith('generated/') and row['deserialization_fields']:expected[path]=expected.get(path,0)+row['deserialization_fields']
  assert expected==per_file
  print('matches canonical manifest',expected==per_file,'differences',[(k,expected.get(k),per_file.get(k)) for k in expected.keys()|per_file.keys() if expected.get(k)!=per_file.get(k)][:15])
