#!/usr/bin/env python3
"""Compare represented model closures with the preceding reviewed prototype."""
from pathlib import Path
import collections,csv,json,hashlib
ROOT=Path(__file__).resolve().parents[1]
OUT=Path(__file__).resolve().parent
BEFORE=ROOT/'consumer-verification/analysis'
AFTER=ROOT/'broad-verification/analysis'
def rows(folder,name):
 with (folder/name).open(newline='') as f:return list(csv.DictReader(f))
def closures(folder):return {r['group']:r for r in rows(folder,'model-group-closures.csv') if r['scope']=='feature'}
def inventory(folder):
 components={r['component']:r for r in rows(folder,'components.csv')}
 items=rows(folder,'items.csv');roots={}
 for i in items:
  name=i['origin'].removeprefix('component:')
  if name in components and i['ident']==components[name]['ident']:roots[name]=i
 return components,items,roots
old,new=closures(BEFORE),closures(AFTER)
bc,bi,br=inventory(BEFORE);ac,ai,ar=inventory(AFTER)
assert bc.keys()==ac.keys()
assert {r['item_id'] for r in bi}=={r['item_id'] for r in ai}
by_id={r['item_id']:r for r in ai}
for r in bi:
 assert all(r[k]==by_id[r['item_id']][k] for k in ['origin','ident','sharing_rule'])
for name in ['dependencies.csv','item-occurrences.csv']:
 assert (BEFORE/name).read_bytes()==(AFTER/name).read_bytes(),name
assert all(c['request_crate']==ac[n]['request_crate'] for n,c in bc.items())
comparison=[]
for name in sorted(old.keys()&new.keys()):
 before,after=old[name],new[name]
 comparison.append({'feature':name,'before_model_modules':int(before['model_modules']),'model_modules':int(after['model_modules']),'removed_model_modules':int(before['model_modules'])-int(after['model_modules']),'before_total_items':int(before['items']),'total_items':int(after['items'])})
with (OUT/'resource-closures.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(comparison[0]),lineterminator='\n');w.writeheader();w.writerows(comparison)
modules={}
for name,item in br.items():
 path=Path(item['emission_path']);module=path.parent.name if path.name=='types.rs' else path.stem
 modules[module]=name
core_flags=sorted(f for f in old if f in modules and bc[modules[f]]['request_crate']=='async-stripe-core')

def profile(folder,features):
 sites={r['emission_path'] for r in rows(folder,'model-module-sccs.csv')}
 availability={r['emission_path']:r['availability'] for r in rows(folder,'model-availability.csv')}
 return {site for site in sites if availability[site]!='always' and (set(availability[site].split('|'))&set(features))}
core_before=profile(BEFORE,core_flags);core_after=profile(AFTER,core_flags)
colocations=rows(AFTER,'model-colocations.csv')
opaque=[r for r in ai if r['kind'].startswith('Opaque')]
remaining_enums=[r for r in ai if r['kind']=='Enum']
assert all('RequestParam' in r['usage'] and 'used_as_request_param: true' in r['usage'] for r in remaining_enums)
summary={
 'baseline_commit':'4b8a58a62d09fcf9bed41e1fd9bf747b4587b542',
 'canonical_item_ids_and_origins_unchanged':len(bi),
 'original_semantic_dependencies_and_provenance_unchanged':True,
 'request_ownership_unchanged':True,
 'core_resource_features':core_flags,
 'core_resource_bundle':{'before_conditional_model_modules':len(core_before),'conditional_model_modules':len(core_after),'before_sources':sorted(core_before),'sources':sorted(core_after)},
 'shared_component_placement':{'before':sum(r['types_crate']=='async-stripe-shared' for r in bc.values()),'after':sum(r['types_crate']=='async-stripe-shared' for r in ac.values()),'note':'Physical colocation grows as inherent accessor families expand; selected-feature compilation is measured separately.'},
 'polymorphic_records':len({r['owner'] for r in colocations}),
 'typed_optional_accessors':len(colocations),
 'opaque_kinds':dict(collections.Counter(r['kind'] for r in opaque)),
 'remaining_request_input_enums':len(remaining_enums),
 'remaining_response_enums':0,
 'features_added':sorted(new.keys()-old.keys()),
 'selected_resources':[r for r in comparison if r['feature'] in ['charge','customer','payment_intent','payment_method','source','confirmation_token','treasury_transaction','invoice','subscription']],
 'interpretation':'Counts exclude unconditional support. Resource features include their HTTP API; models reused by request signatures also contribute. No decoder domain flags were explicitly enabled for these profiles.',
}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ['canonical_item_ids_and_origins_unchanged','polymorphic_records','typed_optional_accessors','opaque_kinds','remaining_response_enums']},indent=2))
print('Core bundle:',len(core_flags),'features;',len(core_before),'->',len(core_after),'conditional model modules')
