# Code Generation Analysis

## Pipeline

- Parsed components: 1470
- Retained components: 1464
- Declared operations: 578
- Generated requests: 547
- Webhook event payloads: 265
- Objects: 6722
- Canonical Rust objects: 6722
- Canonical Rust items: 6859
- Canonical property analysis rounds: 6
- Canonical items with lifetimes: 0
- Canonical items deriving Copy: 538
- Canonical items deriving Eq: 6269
- Fields: 16425
- Enum variants: 20654
- Parsed dependency facts: 3551
- Retained dependency facts: 3543
- Expandable edges used for layout: true
- ID-only edges used for layout: false
- Lowered Rust crate dependencies contain cycles: false
- Crate inference warnings: 0

## Dependency facts

### By representation

- Direct: 918
- Expandable: 326
- IdOnly: 477
- InContainer: 1748
- UnionMember: 74

### By usage

- ModelField: 2385
- RequestParam: 318
- RequestReturn: 562
- WebhookPayload: 278

## Crates

| Crate | Model components | Request components | Requests | Objects | Fields |
|---|---:|---:|---:|---:|---:|
| async-stripe-billing | 63 | 26 | 127 | 885 | 2243 |
| async-stripe-checkout | 0 | 1 | 6 | 290 | 513 |
| async-stripe-connect | 33 | 14 | 51 | 383 | 1205 |
| async-stripe-core | 26 | 22 | 82 | 1277 | 2871 |
| async-stripe-fraud | 30 | 5 | 15 | 76 | 188 |
| async-stripe-issuing | 0 | 8 | 48 | 223 | 578 |
| async-stripe-misc | 125 | 23 | 71 | 715 | 1340 |
| async-stripe-payment | 20 | 9 | 39 | 671 | 1323 |
| async-stripe-product | 2 | 8 | 34 | 78 | 301 |
| async-stripe-reserve | 8 | 0 | 0 | 17 | 50 |
| async-stripe-shared | 1046 | 0 | 0 | 1682 | 4723 |
| async-stripe-terminal | 48 | 5 | 28 | 156 | 464 |
| async-stripe-treasury | 63 | 10 | 46 | 262 | 626 |
| async-stripe-webhook | 0 | 0 | 0 | 7 | 0 |

## Represented model modules

- Model modules: 1465
- Canonical declarations in model modules: 2481
- Struct fields in model modules: 6698
- Enum variants in model modules: 7387
- Cross-module model dependencies: 1956
- Strongly connected components: 1351
- Components containing cross-module cycles: 6
- Largest component: 98 modules

These follow represented declaration and request type uses after placement. The model graph excludes request modules, webhook modules, ID-only modules, and intra-module references; isolated model modules are retained. `model-module-dependencies.csv` also includes the excluded edges.

SCC module/item/field/variant counts cover the entire component and repeat for each membership row. Counts use canonical declarations once, rather than inferred occurrences, and exclude generated helper declarations and implicit unknown variants. The reports do not include facade reexports, handwritten code, or feature activation, and do not measure a consumer's compiled source closure.
