Codegen currently couples inferred objects, crate placement, declaration traversal, and rendered paths. This separates those concerns so crate-organization experiments can be analyzed while preserving the generated bindings.

Based on the [output-handling draft (#4)](https://github.com/mzeitlin11/async-stripe/pull/4), which includes the CI verification and CLI/spec-cache changes. This comparison shows the remaining refactor.

## Changes

- Give components, operations, and generated declarations explicit identities; keep names and output locations separate.
- Record dependency facts with their usage and reference kind, then infer and freeze crate placement from a selected policy.
- Lower declarations and references into an item catalog used by rendering and lifetime/`Copy`/`Eq` analysis.
- Route canonical declarations through their selected item placements with one declaration writer. IDs, request declarations, nested types, and webhook unions follow their own placement; module declarations, exports, references, and webhook feature gates follow those decisions.
- Derive generated Cargo dependencies and feature forwarding from lowered Rust declarations, request signatures and constructor fields, associated ID types, and public facade reexports. Resolve references through item placement; validate local visibility and reject crate cycles before emission. Report the actual Rust crate graph separately from the spec projection used for placement inference.
- Separate candidate matching, shared naming, and usage compatibility. Retain sharing rules and original occurrence locations/usages; expose them in `items.csv` and `item-occurrences.csv`.
- Replace `graph` with `analyze`, producing deterministic CSV reports and DOT graphs. `generate --report-dir` writes reports alongside generation and replaces `--emit-warnings`; the update workflow reads the warning CSV.
- Materialize bindings and reports from file sets, preserving the prerequisite's staging guards, formatter diagnostics, and installation preflight.

## Current limits

Sharing remains component-local and preserves the existing decisions before item allocation. Fieldless enum matching is independent of occurrence names and documentation; the model-field rule can combine model and request usages. Composite matching still includes field documentation and nested metadata, and other candidates require identical usage. Broader structural matching and usage compatibility remain follow-up work.

The default placement policy keeps IDs with their models and nested declarations with their parents. Emission now supports independently placed public declarations, with visibility, local-reference, duplicate-name/module, and exactly-once checks. No new production placement policy is selected. The handwritten webhook manifest still requires the corresponding dependency and feature when a payload moves. `analyze --without-expandables` changes placement analysis only; it does not implement a different generated API representation. Analysis reports the remaining Rust dependencies and cycles for that hypothetical placement.

## Validation

- Rust 1.89: 61 tests (including sharing/provenance, crate dependencies, independent item emission, facade exports, visibility, and webhook feature gates), strict Clippy across all targets, and release build pass.
- All 13 generated crates, plus types and webhooks, compile with all features enabled on Rust 1.89. A full-spec placement probe moves `CustomerId` and a request return union to shared and a webhook union to payment; that output compiles both with all features and without default features, including a consumer of the existing `CustomerId` facade.
- Nightly formatting for the generator and workspace, plus actionlint, pass.
- Full generation matches all 1,757 artifacts on pinned spec `v2494` and all 1,728 on `v2343` byte for byte; installation leaves checked-in artifacts unchanged.
- Existing CSV values and inference projections are unchanged; `items.csv` adds actual emission paths and public crates; repeated analysis produces 17 identical files. Generated manifest dependencies and feature forwarding match the Rust graph. Changing graph selection removes stale owned reports and preserves unrelated files.
- Formatter failure reports stdout/stderr and skips installation. Partial staging failures remain safe to retry.
