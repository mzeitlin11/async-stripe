## Crate Inference Warnings

The following components could not have their crate automatically inferred and were auto-assigned. Consider adding explicit path entries in `openapi/gen_crates.toml` to make these assignments permanent.

| Component | Assigned Crate | Depended On By | Candidate Crates |
|-----------|---------------|----------------|------------------|
| `address` | `issuing` | `account_business_profile`, `billing_details`, `confirmation_tokens_resource_shipping`, `customer`, `funding_instructions_bank_transfer_aba_record`, `funding_instructions_bank_transfer_iban_record`, `funding_instructions_bank_transfer_sort_code_record`, `funding_instructions_bank_transfer_spei_record`, `funding_instructions_bank_transfer_swift_record`, `funding_instructions_bank_transfer_zengin_record`, `gelato_document_report`, `gelato_verified_outputs`, `invoice`, `issuing_card_shipping`, `issuing_card_shipping_address_validation`, `issuing_cardholder_address`, `legal_entity_company`, `payment_method_card_wallet_masterpass`, `payment_method_card_wallet_visa_checkout`, `payment_method_details_card_wallet_masterpass`, `payment_method_details_card_wallet_visa_checkout`, `payment_pages_checkout_session_checkout_address_details`, `payment_pages_checkout_session_customer_details`, `person`, `shipping`, `source_owner`, `tax_product_resource_tax_settings_head_office`, `treasury_shared_resource_billing_details` | `connect`, `payment`, `core`, `issuing`, `misc`, `billing`, `checkout`, `shared`, `treasury` |
| `billing_details` | `payment` | `charge`, `confirmation_tokens_resource_payment_method_preview`, `payment_method` | `core`, `payment` |

### Suggested `gen_crates.toml` entries

Add the following paths to the appropriate crate's `paths` array:

```toml
# currently auto-assigned to "issuing"
"address",
# currently auto-assigned to "payment"
"billing_details",
```
