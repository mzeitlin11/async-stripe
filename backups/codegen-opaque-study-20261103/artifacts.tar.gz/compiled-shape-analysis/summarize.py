#!/usr/bin/env python3
"""Account canonical declarations from actual generated Rust syntax and compiled files."""
from pathlib import Path
import csv,json,collections
ROOT=Path(__file__).resolve().parents[1]
OUT=Path(__file__).resolve().parent
SCENARIOS={'before':ROOT/'consumer-verification','after':ROOT/'broad-verification'}
def rows(folder,name):
 with (folder/name).open(newline='') as file:return list(csv.DictReader(file))
def stats():return dict(modules=0,declarations=0,structs=0,struct_fields=0,public_fields=0,enums=0,enum_variants=0,enum_payload_fields=0,opaque_wrappers=0,ids=0,raw_bags=0)
def add_shape(target,kind,shape):
 target['declarations']+=1
 if kind=='Struct':
  target['structs']+=1;target['struct_fields']+=shape['fields'];target['public_fields']+=shape['public_fields'];target['raw_bags']+=shape['raw_bags']
 elif kind in {'Enum','FieldlessEnum'}:
  target['enums']+=1;target['enum_variants']+=shape['variants'];target['enum_payload_fields']+=shape['fields']
 elif kind in {'OpaqueObject','OpaqueRecord'}:target['opaque_wrappers']+=1
 elif kind=='IdNewtype':target['ids']+=1
 else:raise AssertionError(kind)
result={};detail=[]
for label,folder in SCENARIOS.items():
 analysis=folder/'analysis';shapes=json.loads((OUT/f'{label}-shapes.json').read_text())
 compiled=set(json.loads((ROOT/f'broad-model-impact/{label}-compiled-sources.json').read_text()))
 model_sites={r['emission_path'] for r in rows(analysis,'model-module-sccs.csv')}
 items=rows(analysis,'items.csv');by_site=collections.defaultdict(list)
 for item in items:by_site[item['emission_path']].append(item)
 availability={r['emission_path']:r['availability'] for r in rows(analysis,'model-availability.csv')}
 groups=collections.defaultdict(stats)
 full=collections.defaultdict(stats)
 for path,declarations in by_site.items():
  if not path.startswith('crates/'):continue
  generated=path.replace('crates/','generated/',1);crate=Path(path).parts[1]
  if path in model_sites:category='models'
  elif path.endswith('/requests.rs'):category='requests'
  elif all(item['kind'] in {'IdNewtype','OpaqueObject'} for item in declarations):category='reference_support'
  else:raise AssertionError(path)
  live=generated in compiled
  if live:groups[(crate,category)]['modules']+=1
  if path in model_sites:full[crate]['modules']+=1
  for item in declarations:
   shape=shapes[generated].get(item['ident']);assert shape is not None,(label,generated,item['ident'])
   expected={'Struct':'Struct','Enum':'Enum','FieldlessEnum':'Enum','IdNewtype':'IdNewtype','OpaqueObject':'OpaqueObject','OpaqueRecord':'OpaqueRecord'}[item['kind']]
   assert shape['kind']==expected,(label,item,shape)
   if live:add_shape(groups[(crate,category)],item['kind'],shape)
   if path in model_sites:add_shape(full[crate],item['kind'],shape)
   detail.append(dict(scenario=label,crate=crate,category=category,compiled=live,ident=item['ident'],item_id=item['item_id'],kind=item['kind'],fields=shape['fields'] if item['kind']=='Struct' else 0,enum_variants=shape['variants'],raw_bags=shape['raw_bags'],availability=availability[path],emission_path=path))
 result[label]={'core_profile':{crate:{category:groups[(crate,category)] for c,category in sorted(groups) if c==crate} for crate in sorted({c for c,_ in groups})},'full_catalog_models':dict(sorted(full.items())),'actual_compiled_source_files_by_crate':dict(sorted(collections.Counter(Path(path).parts[1] for path in compiled).items()))}
with (OUT/'declarations.csv').open('w',newline='') as file:
 writer=csv.DictWriter(file,fieldnames=list(detail[0]),lineterminator='\n');writer.writeheader();writer.writerows(detail)
(OUT/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
for label in result:
 print(label,'CORE PROFILE',json.dumps(result[label]['core_profile'],indent=2))
